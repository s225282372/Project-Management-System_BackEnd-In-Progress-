﻿using IT_ProjectManagement.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace IT_ProjectManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProjectsController : ControllerBase
    {
        private readonly ProjectContext projectContext;

        public ProjectsController(ProjectContext projectContext)
        {
            this.projectContext = projectContext;

        }

        [HttpGet]
        [Route("GetProjects")]
        public List<Projects> GetProjects()
        {
            return projectContext.Projects.ToList();
        }

        //[HttpGet]
        //[Route("GetProject")]
        //public Projects GetProject(string name)
        //{
        //    return ProjectContext.Projects.Where(x => x.Name == name).FirstOrDefault();
        //}

        //[HttpGet]
        //[Route("GetTitle")]
        //public Projects GetTitle(string jobTitle)
        //{
        // return ProjectContext.Projects.Where(x => x.JobTitle == jobTitle).ToList();
        // return ProjectContext.Projects.Where(x => x.JobTitle == jobTitle).FirstOrDefault();
        // }

        [HttpPost]
        [Route("AddProjects")]
        public string AddProject(Projects projects)
        {

            string response = string.Empty;
            projectContext.Projects.Add(projects);
            projectContext.SaveChanges();
            return "Project successfully added";
        }

        [HttpPut]
        [Route("UpdateProjects")]
        public string UpdateProject(Projects projects)
        {
            string response = string.Empty;
            projectContext.Entry(projects).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            projectContext.SaveChanges();
            return "Project successfully Updated";
        }

        [HttpDelete]
        [Route("DeleteProjects")]
        public string DeleteProject(int id)
        {
            Projects projects = projectContext.Projects.Where(x => x.Id == id).FirstOrDefault();
            if (projects != null)
            {
                projectContext.Projects.Remove(projects);
                projectContext.SaveChanges();
                return "Project successfully Deleted";
            }
            else
            {
                return "Project not found";
            }

        }
    }
}
