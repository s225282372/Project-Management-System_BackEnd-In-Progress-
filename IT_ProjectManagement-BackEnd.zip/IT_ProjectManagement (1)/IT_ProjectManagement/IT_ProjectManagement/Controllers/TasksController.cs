﻿using IT_ProjectManagement.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace IT_ProjectManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TasksController : ControllerBase
    {
        private readonly TaskContext taskContext;

        public TasksController(TaskContext taskContext)
        {
            this.taskContext = taskContext;

        }

        [HttpGet]
        [Route("GetTasks")]
        public List<Tasks> GetTasks()
        {
            return taskContext.Tasks.ToList();
        }

       //Boizin, where you able to see the list of employess that have the same jobTitle ???


        //[HttpGet]
        //[Route("Gettask")]
        //public Tasks Gettask(string name)
        //{
        //    return taskContext.Tasks.Where(x => x.Name == name).FirstOrDefault();
        //}

        //[HttpGet]
        //[Route("GetTitle")]
        //public Tasks GetTitle(string jobTitle)
        //{
            // return taskContext.tasks.Where(x => x.JobTitle == jobTitle).ToList();
           // return taskContext.Tasks.Where(x => x.JobTitle == jobTitle).FirstOrDefault();
       // }

        [HttpPost]
        [Route("AddTasks")]
        public string AddTask(Tasks tasks)
        {

            string response = string.Empty;
            taskContext.Tasks.Add(tasks);
            taskContext.SaveChanges();
            return "task successfully added";
        }

        [HttpPut]
        [Route("UpdateTasks")]
        public string UpdateTask(Tasks tasks)
        {
            string response = string.Empty;
            taskContext.Entry(tasks).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            taskContext.SaveChanges();
            return "task successfully Updated";
        }

        [HttpDelete]
        [Route("DeleteTasks")]
        public string DeleteTask(int id)
        {
            Tasks tasks = taskContext.Tasks.Where(x => x.Id == id).FirstOrDefault();
            if (tasks != null)
            {
                taskContext.Tasks.Remove(tasks);
                taskContext.SaveChanges();
                return "task successfully Deleted";
                
            }
            else
            {
                return "task not found";
            }

        }

    }
}
