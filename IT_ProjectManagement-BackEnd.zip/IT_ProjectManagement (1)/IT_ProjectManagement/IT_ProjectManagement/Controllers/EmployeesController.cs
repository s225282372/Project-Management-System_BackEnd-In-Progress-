﻿using IT_ProjectManagement.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Numerics;

namespace IT_ProjectManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeesController : ControllerBase
    {
        private readonly EmployeeContext employeeContext;

        public EmployeesController(EmployeeContext employeeContext)
        {
            this.employeeContext = employeeContext;

        }
        
        [HttpGet]
        [Route("GetEmployees")]
        public List<Employees> GetEmployees()
        {
            return employeeContext.Employees.ToList();
        }

        [HttpGet]
        [Route("GetEmployee/{id}")]
        public Employees GetEmployee(int id)
        {
            return employeeContext.Employees.Where(x => x.Id == id).FirstOrDefault();
        }
          
        [HttpGet]
        [Route("GetTitle")]
        public Employees GetTitle(string jobTitle)
        {
            // return employeeContext.Employees.Where(x => x.JobTitle == jobTitle).ToList();
            return employeeContext.Employees.Where(x => x.JobTitle == jobTitle).FirstOrDefault();
        }

        [HttpPost]
        [Route("AddEmployees")]
        public string AddEmployee(Employees employees)
        {

            string response = string.Empty;
            employeeContext.Employees.Add(employees);
            employeeContext.SaveChanges();
            return "Employee successfully added";
        }

        [HttpPut]
        [Route("UpdateEmployees/{id}")]
        public string UpdateEmployee(Employees employees)
        {
            string response = string.Empty;
            employeeContext.Entry(employees).State=Microsoft.EntityFrameworkCore.EntityState.Modified;
            employeeContext.SaveChanges();
            return "Employee successfully Updated";
        }

        [HttpDelete]
        [Route("DeleteEmployees/{id}")]
        public string DeleteEmployee(int id)
        {
            Employees employees = employeeContext.Employees.Where(x => x.Id == id).FirstOrDefault();
            if (employees != null)
            {
                employeeContext.Employees.Remove(employees);
                employeeContext.SaveChanges();
                return "Employee successfully Deleted";
            }
            else
            {
                return "Employee not found";
            }
            
        }

        
    }
}
