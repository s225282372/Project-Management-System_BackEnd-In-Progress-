﻿namespace IT_ProjectManagement
{
    public class ProjectManagerContext
    {
    }
}
