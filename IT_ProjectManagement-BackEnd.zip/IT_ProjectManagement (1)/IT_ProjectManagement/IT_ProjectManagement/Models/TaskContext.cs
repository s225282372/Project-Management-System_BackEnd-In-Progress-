﻿using Microsoft.EntityFrameworkCore;

namespace IT_ProjectManagement.Models
{
    public class TaskContext: DbContext
    {
        public TaskContext(DbContextOptions<TaskContext> options) : base(options)
        {

        }
        public DbSet<Tasks> Tasks { get; set; }
    }
}
