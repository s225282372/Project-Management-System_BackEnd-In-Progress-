﻿using System.ComponentModel.DataAnnotations;

namespace IT_ProjectManagement.Models
{
    public class Employees
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [StringLength(50)]
        public string Name { get; set; }

        [Required]
        [StringLength(50)]
        public string Surname { get; set; }

        [StringLength(50)]
        public string Email { get; set; }

        [Required]
        [StringLength(50)]
        public string JobTitle { get; set; }

        // Navigation property
        //public List<Tasks> AssignedTasks { get; set; }


    }
}
