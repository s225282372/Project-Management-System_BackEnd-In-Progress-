﻿using Microsoft.EntityFrameworkCore;

namespace IT_ProjectManagement.Models
{
    public class ProjectContext: DbContext
    {
        public ProjectContext(DbContextOptions <ProjectContext> options) : base(options)
        {

        }
        public DbSet<Projects> Projects { get; set; }
    }
}
