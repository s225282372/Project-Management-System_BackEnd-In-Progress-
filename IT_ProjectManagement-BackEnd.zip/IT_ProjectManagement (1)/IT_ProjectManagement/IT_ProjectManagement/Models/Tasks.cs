﻿using System.ComponentModel.DataAnnotations;

namespace IT_ProjectManagement.Models
{
    public class Tasks
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [StringLength(50)]
        public string title { get; set; }

        [Required]
        [StringLength(50)]
        public string Description { get; set; }

        [Required]
        [StringLength(50)]
        public string Status { get; set; }

        //public DateTime AssignedCompletionTime { get; set; }
        //public DateTime? ActualCompletionTime { get; set; }

        // Foreign key for User
        //public int AssignedToUserId { get; set; }

        // Navigation property
        //public Employees AssignedToUser { get; set; }

        // Foreign key for Project
        //public int ProjectId { get; set; }

        // Navigation property
        //public Projects Projects { get; set; }

    }
}
